package net.MiniGameKing.BetterItems.Main;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.ConsoleCommandSender;
import org.bukkit.plugin.java.JavaPlugin;

import net.MiniGameKing.BetterItems.Items.ItemManager;

public class Main extends JavaPlugin {

	ConsoleCommandSender console = Bukkit.getConsoleSender();

	@Override
	public void onEnable() {
		ItemManager.init();
		console.sendMessage(ChatColor.translateAlternateColorCodes('&',"&7[&1BetterItems&7] &aPlugin BetterItems has been enabled!"));
	}
	
	@Override
	public void onDisable() {
		console.sendMessage(ChatColor.translateAlternateColorCodes('&',"&7[&1BetterItems&7] &aPlugin BetterItems has been disabled!"));
	}
}

package net.MiniGameKing.BetterItems.Items;

import java.util.ArrayList;
import java.util.List;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Color;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.ShapedRecipe;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.inventory.meta.LeatherArmorMeta;

public class ItemManager {
	
	public static ItemStack Em_Helm;
	public static ItemStack Em_Chest;
	public static ItemStack Em_Legg;
	public static ItemStack Em_Boots;
	public static ItemStack Bett_Helm;
	public static ItemStack Bett_Chest;
	public static ItemStack Bett_Legg;
	public static ItemStack Bett_Boots;
	
	public static void init() {
		createEm_Helm();
		createEm_Chest();
		createEm_Legg();
		createEm_Boots();
		createBett_Helm();
		createBett_Chest();
		createBett_Legg();
		createBett_Boots();
		normalRecepes();
	}
	//emerald Armor (change the stats how u want!)
	private static void createEm_Helm() {
		ItemStack item = new ItemStack(Material.LEATHER_HELMET);
		LeatherArmorMeta helmet = (LeatherArmorMeta) item.getItemMeta();
		helmet.setColor(Color.LIME);
		helmet.setDisplayName(ChatColor.GREEN + "Emerald Helmet");
		helmet.addItemFlags(ItemFlag.HIDE_ENCHANTS);
		List<String> lore = new ArrayList<>();
		lore.add(ChatColor.DARK_GREEN + "Grants protection against mobs");
		helmet.setLore(lore);
		helmet.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
		helmet.addEnchant(Enchantment.PROTECTION_PROJECTILE, 10, true);
		helmet.addItemFlags(ItemFlag.HIDE_ENCHANTS);
		item.setItemMeta(helmet);
		Em_Helm = item; 
		
		ShapedRecipe recipe = new ShapedRecipe(NamespacedKey.minecraft("em_helm"), item);
		recipe.shape("EEE", "E E", "   ");
		recipe.setIngredient('E', Material.EMERALD);
		Bukkit.getServer().addRecipe(recipe);
	}
	
	private static void createEm_Chest() {
		ItemStack item = new ItemStack(Material.LEATHER_CHESTPLATE);
		LeatherArmorMeta helmet = (LeatherArmorMeta) item.getItemMeta();
		helmet.setColor(Color.LIME);
		helmet.setDisplayName(ChatColor.GREEN + "Emerald Chestplate");
		helmet.addItemFlags(ItemFlag.HIDE_ENCHANTS);
		List<String> lore = new ArrayList<>();
		lore.add(ChatColor.DARK_GREEN + "Grants protection against mobs");
		helmet.setLore(lore);
		helmet.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
		helmet.addEnchant(Enchantment.PROTECTION_PROJECTILE, 10, true);
		helmet.addItemFlags(ItemFlag.HIDE_ENCHANTS);
		item.setItemMeta(helmet);
		Em_Chest = item;
		
		ShapedRecipe recipe = new ShapedRecipe(NamespacedKey.minecraft("em_chest"), item);
		recipe.shape("E E", "EEE", "EEE");
		recipe.setIngredient('E', Material.EMERALD);
		Bukkit.getServer().addRecipe(recipe);
	}
	
	private static void createEm_Legg() {
		ItemStack item = new ItemStack(Material.LEATHER_LEGGINGS);
		LeatherArmorMeta helmet = (LeatherArmorMeta) item.getItemMeta();
		helmet.setColor(Color.LIME);
		helmet.setDisplayName(ChatColor.GREEN + "Emerald Leggings");
		List<String> lore = new ArrayList<>();
		lore.add(ChatColor.DARK_GREEN + "Grants protection against mobs");
		helmet.addItemFlags(ItemFlag.HIDE_ENCHANTS);
		helmet.setLore(lore);
		helmet.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
		helmet.addEnchant(Enchantment.PROTECTION_PROJECTILE, 10, true);
		helmet.addItemFlags(ItemFlag.HIDE_ENCHANTS);
		item.setItemMeta(helmet);
		Em_Legg = item;
		
		ShapedRecipe recipe = new ShapedRecipe(NamespacedKey.minecraft("em_legg"), item);
		recipe.shape("EEE", "E E", "E E");
		recipe.setIngredient('E', Material.EMERALD);
		Bukkit.getServer().addRecipe(recipe);
	}
	
	private static void createEm_Boots() {
		ItemStack item = new ItemStack(Material.LEATHER_BOOTS);
		LeatherArmorMeta helmet = (LeatherArmorMeta) item.getItemMeta();
		helmet.setColor(Color.LIME);
		helmet.setDisplayName(ChatColor.GREEN + "Emerald Boots");
		helmet.addItemFlags(ItemFlag.HIDE_ENCHANTS);
		List<String> lore = new ArrayList<>();
		lore.add(ChatColor.DARK_GREEN + "Grants protection against mobs");
		helmet.setLore(lore);
		helmet.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
		helmet.addEnchant(Enchantment.PROTECTION_PROJECTILE, 10, true);
		helmet.addItemFlags(ItemFlag.HIDE_ENCHANTS);
		item.setItemMeta(helmet);
		Em_Boots = item;
		
		ShapedRecipe recipe = new ShapedRecipe(NamespacedKey.minecraft("em_boots"), item);
		recipe.shape("   ", "E E", "E E");
		recipe.setIngredient('E', Material.EMERALD);
		Bukkit.getServer().addRecipe(recipe);
	}

	//Fire Armor (change the stats how u want!)

	private static void createBett_Helm() {
		ItemStack item = new ItemStack(Material.NETHERITE_HELMET);
		ItemMeta meta = item.getItemMeta();
		meta.setDisplayName(ChatColor.GRAY + "Fire Helmet");
		meta.addEnchant(Enchantment.PROTECTION_FIRE, 100, true);
		meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
		List<String> lore = new ArrayList<>();
		lore.add(ChatColor.DARK_GREEN + "Grants inmunnity against fire");
		meta.setLore(lore);
		item.setItemMeta(meta);
		Bett_Helm = item;
		
		ShapedRecipe recipe = new ShapedRecipe(NamespacedKey.minecraft("bett_helm"), item);
		recipe.shape("EEE", "E E", "   ");
		recipe.setIngredient('E', Material.NETHERITE_INGOT);
		Bukkit.getServer().addRecipe(recipe);
	}
	
	private static void createBett_Legg() {
		ItemStack item = new ItemStack(Material.NETHERITE_LEGGINGS);
		ItemMeta meta = item.getItemMeta();
		meta.setDisplayName(ChatColor.GRAY + "Fire Leggings");
		meta.addEnchant(Enchantment.PROTECTION_FIRE, 100, true);
		meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
		List<String> lore = new ArrayList<>();
		lore.add(ChatColor.DARK_GREEN + "Grants inmunnity against fire");
		meta.setLore(lore);
		item.setItemMeta(meta);
		Bett_Helm = item;
		ShapedRecipe recipe = new ShapedRecipe(NamespacedKey.minecraft("bett_legg"), item);
		recipe.shape("EEE", "E E", "E E");
		recipe.setIngredient('E', Material.NETHERITE_INGOT);
		Bukkit.getServer().addRecipe(recipe);
	}
	
	private static void createBett_Chest() {
		ItemStack item = new ItemStack(Material.NETHERITE_CHESTPLATE);
		ItemMeta meta = item.getItemMeta();
		meta.setDisplayName(ChatColor.GRAY + "Fire Chestplate");
		meta.addEnchant(Enchantment.PROTECTION_FIRE, 100, true);
		meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
		List<String> lore = new ArrayList<>();
		lore.add(ChatColor.DARK_GREEN + "Grants inmunnity against fire");
		meta.setLore(lore);
		item.setItemMeta(meta);
		Bett_Helm = item;
		
		ShapedRecipe recipe = new ShapedRecipe(NamespacedKey.minecraft("bett_chest"), item);
		recipe.shape("E E", "EEE", "EEE");
		recipe.setIngredient('E', Material.NETHERITE_INGOT);
		Bukkit.getServer().addRecipe(recipe);
	}
	private static void createBett_Boots() {
		ItemStack item = new ItemStack(Material.NETHERITE_BOOTS);
		ItemMeta meta = item.getItemMeta();
		meta.setDisplayName(ChatColor.GRAY + "Fire Boots");
		meta.addEnchant(Enchantment.PROTECTION_FIRE, 100, true);
		meta.addItemFlags(ItemFlag.HIDE_ENCHANTS);
		List<String> lore = new ArrayList<>();
		lore.add(ChatColor.DARK_GREEN + "Grants inmunnity against fire");
		meta.setLore(lore);
		item.setItemMeta(meta);
		Bett_Helm = item;

		ShapedRecipe recipe = new ShapedRecipe(NamespacedKey.minecraft("bett_boots"), item);
		recipe.shape("   ", "E E", "E E");
		recipe.setIngredient('E', Material.NETHERITE_INGOT);
		Bukkit.getServer().addRecipe(recipe);
	}
	@SuppressWarnings("deprecation")
	private static void normalRecepes() {

	ShapedRecipe purpur_block = new ShapedRecipe(NamespacedKey.minecraft("purpur_recipe"), new ItemStack(Material.PURPUR_BLOCK));
	purpur_block.shape("DDD", "DBD", "DDD");
	purpur_block.setIngredient('D', Material.PURPLE_DYE);
	purpur_block.setIngredient('B', Material.BRICK);
	Bukkit.getServer().addRecipe(purpur_block);
	
	ShapedRecipe endrod = new ShapedRecipe(NamespacedKey.minecraft("endrod_recipe"), new ItemStack(Material.END_ROD));
	endrod.shape(" G ", " G ", "PPP");
	endrod.setIngredient('G', Material.GLOWSTONE);
	endrod.setIngredient('P', Material.PURPUR_SLAB);
	Bukkit.getServer().addRecipe(endrod);
	
	ShapedRecipe enderspawnegg = new ShapedRecipe(NamespacedKey.minecraft("enderman_recipe"), new ItemStack(Material.ENDERMAN_SPAWN_EGG));
	enderspawnegg.shape("OBO", "OEO", "OOO");
	enderspawnegg.setIngredient('O', Material.OBSIDIAN);
	enderspawnegg.setIngredient('B', Material.BLAZE_ROD);
	enderspawnegg.setIngredient('E', Material.LEGACY_EYE_OF_ENDER);
	Bukkit.getServer().addRecipe(enderspawnegg);

}

	//Your own item code here! Copying is OK for beginner's.


}
